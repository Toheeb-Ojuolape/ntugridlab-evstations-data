def showhome():
    html_content = """
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>NTU GRIDLAB</title>
    </head>
    <body>
        <h1>EV electricity demand prediction API</h1>
    </body>
    </html>
    """
    return html_content