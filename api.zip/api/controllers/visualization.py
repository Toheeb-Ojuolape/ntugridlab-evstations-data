import matplotlib.pyplot as plt
from io import BytesIO
import base64
import pandas as pd

# Use the 'Agg' backend for Matplotlib
plt.switch_backend('Agg')

def create_visualization(monthly_data):
    plt.figure(figsize=(10, 6))
    plt.plot(monthly_data['month'], monthly_data['kWhDelivered'], marker='o')
    plt.title('Monthly kWh Delivered')
    plt.xlabel('Month')
    plt.ylabel('kWh Delivered')
    plt.grid(True)
    
    # Save the plot to a BytesIO object
    img = BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)
    
    # Encode the image to base64 string
    plot_url = base64.b64encode(img.getvalue()).decode()
    
    html_content = f"""
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Data Visualization</title>
    </head>
    <body>
        <h1>Monthly kWh Delivered</h1>
        <img src="data:image/png;base64,{plot_url}" alt="Monthly kWh Delivered">
    </body>
    </html>
    """
    return html_content
