import pandas as pd
import numpy as np
import os
import pickle
import logging
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout
from tensorflow.keras.optimizers import Adam
from flask import Flask, request, jsonify
from flask_cors import CORS
from controllers.visualization import create_visualization
from controllers.home import showhome

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Directories
model_data_dir = "../caltech_model_data"
weather_data_file = "../caltech_weather_monthmonthly_weather_data.csv"

# Load weather data
weather_data = pd.read_csv(weather_data_file)
weather_data["month"] = pd.to_datetime(weather_data["month"])

# Initialize lists to store all station data
all_station_data = []

# Loop through each CSV file in the directory
for filename in os.listdir(model_data_dir):
    if filename.endswith(".csv"):
        file_path = os.path.join(model_data_dir, filename)

        # Load the CSV file
        station_data = pd.read_csv(file_path)

        # Convert 'month' column to datetime format
        station_data["month"] = pd.to_datetime(station_data["month"])

        # Ensure 'kWhDelivered' is numeric
        station_data["kWhDelivered"] = pd.to_numeric(
            station_data["kWhDelivered"], errors="coerce"
        )  # coerce errors to NaN

        # Drop any rows with missing values
        station_data.dropna(inplace=True)

        # Append to list
        all_station_data.append(station_data)

# Concatenate all station data into one DataFrame
data = pd.concat(all_station_data, ignore_index=True)

# Include the number of files as a feature
data["num_files"] = len(all_station_data)

# Aggregate kWhDelivered by month
monthly_data = data.groupby(["month"])["kWhDelivered"].sum().reset_index()

# Define features (X) and target (y)
features = [
    "MinTemp",
    "MaxTemp",
    "AvgTemp",
    "AvgPrecipitation",
    "AvgHumidity",
    "AvgWindSpeed",
    "num_files",
]
target = "kWhDelivered"

# Merge weather data with monthly aggregated kWhDelivered
merged_data = pd.merge(
    monthly_data,
    data[features + ["month"]].drop_duplicates(subset=["month"]),
    on="month",
    how="left",
)

# Split the data into training and testing sets
X = merged_data[features]
y = merged_data[target]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# Scale the data
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Build the neural network model
model = Sequential(
    [
        Dense(64, activation="relu", input_shape=(len(features),)),
        Dropout(0.2),
        Dense(32, activation="relu"),
        Dropout(0.2),
        Dense(1),
    ]
)

# Compile the model
model.compile(optimizer=Adam(learning_rate=0.001), loss="mean_squared_error")

# Train the model
model.fit(X_train_scaled, y_train, epochs=50, batch_size=32, validation_split=0.2)

# Save the model and scaler for reuse
model.save("energy_prediction_model.keras")
scaler_filename = "scaler.pkl"
with open(scaler_filename, "wb") as f_out:
    pickle.dump(scaler, f_out)

# Flask API setup
app = Flask(__name__)
CORS(app)  # Enable CORS for all endpoints


@app.route("/", methods=["GET"])
def home():
    return showhome()


@app.route("/predict", methods=["GET"])
def predict():
    try:
        # Retrieve query parameters
        month = int(request.args.get("month"))
        year = int(request.args.get("year"))

        # Find weather data for the specified month and year
        weather_row = weather_data[(weather_data['month'].dt.year == year) & (weather_data['month'].dt.month == month)]

        if weather_row.empty:
            return jsonify({"error": f"No weather data found for {year}-{month}"}), 400

        # Extract weather parameters
        MinTemp = float(weather_row["MinTemp"])
        MaxTemp = float(weather_row["MaxTemp"])
        AvgTemp = float(weather_row["AvgTemp"])
        AvgPrecipitation = float(weather_row["AvgPrecipitation"])
        AvgHumidity = float(weather_row["AvgHumidity"])
        AvgWindSpeed = float(weather_row["AvgWindSpeed"])

    except (ValueError, TypeError) as e:
        return (
            jsonify(
                {"error": "Invalid input for one or more parameters", "details": str(e)}
            ),
            400,
        )

    logger.info(
        f"Received data - Month: {month}, Year: {year}, MinTemp: {MinTemp}, MaxTemp: {MaxTemp}, AvgTemp: {AvgTemp}, AvgPrecipitation: {AvgPrecipitation}, AvgHumidity: {AvgHumidity}, AvgWindSpeed: {AvgWindSpeed}"
    )

    # Prepare input data
    input_data = pd.DataFrame(
        {
            "MinTemp": [MinTemp],
            "MaxTemp": [MaxTemp],
            "AvgTemp": [AvgTemp],
            "AvgPrecipitation": [AvgPrecipitation],
            "AvgHumidity": [AvgHumidity],
            "AvgWindSpeed": [AvgWindSpeed],
            "num_files": [len(all_station_data)],
        }
    )

    logger.info(f"Input data: {input_data}")

    # Scale input data
    scaled_input = scaler.transform(input_data)

    logger.info(f"Scaled input: {scaled_input}")

    # Predict using the model
    prediction = model.predict(scaled_input)

    logger.info(f"Raw prediction result: {prediction}")

    # Convert prediction from float32 to float
    predicted_kWh = float(prediction[0, 0])  # Convert to standard Python float

    logger.info(f"Predicted kWh: {predicted_kWh}")

    return jsonify({"predicted_kWh": predicted_kWh})


@app.route("/visualize", methods=["GET"])
def visualize():
    return create_visualization(monthly_data)


if __name__ == "__main__":
    app.run(debug=True, port=5000)
